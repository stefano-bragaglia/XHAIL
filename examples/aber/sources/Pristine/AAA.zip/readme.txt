call process on aaa to give network 

and then call xhail on network, data and theory
